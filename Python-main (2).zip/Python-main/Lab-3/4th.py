# 4)	Write a function that removes one string from another string, if present. E.g. Onestring = “abcdef”, removestring = “cd”. The finalstring should contain “abef”.
a = "aashish"
b = "sh"
c = a.replace(b,"")
print(c)
