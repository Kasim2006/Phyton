# 3)	Accept two strings. Check whether one string is there in another string.
a = "aashish"
b = "sh"
print(b in a)
