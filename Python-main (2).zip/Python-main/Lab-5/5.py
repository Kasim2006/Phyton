# 5.	A list contains 5 strings. Convert all these strings to uppercase.
def strng():
    lst =["Ram","Hari","Vishnu","Pratik","sallubhai"]
    lst2=[]
    for i in lst:
        m = i.upper()
        lst2.append(m)
    print(lst2)
strng()
