#Calculate net sales where net sales = gross sales – 10% discount of gross sales.
sale= int(input("Enter the gross sale:"))
sale
print("Net sale is",sale-((10/100)*sale))
