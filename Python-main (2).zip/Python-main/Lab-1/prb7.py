#TO CONVERT MINUTE INTO HOURS
a = int(input("Enter minutes:"))
b = a/60
print("The conversion of",a,"minutes is",b,"hours")