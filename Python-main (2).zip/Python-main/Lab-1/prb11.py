#Convert grams into kg.
a = int(input("Enter the number of grams:"))
b = a/1000
print("The conversion of",a,"grams is",b,"kg")