#The addition,substraction,multiplication and division of two numbers.
a = int(input("Enter 1st number:"))
b = int(input("Enter 2nd number:"))
c = a+b
d = a-b
e = a*b
f= a/b
print(a,"+",b,"is:",c)
print(a,"-",b,"is:",d)
print(a,"*",b,"is:",e)
print(a,"/",b,"is:",f)
