#To multiply any two number
def mult():
    a = float(input("Enter the first number:"))
    b = float(input("Enter the second number:"))
    c= a*b
    print(c)


mult()
