#To subtract any two numbers.
def subst():
     m=int(input("Enter 1st number:")
     n=int(input("Enter 2nd number:")
     c = m-n
     print(c)
subst()
           
