#Convert Rs. into dollars where 1 $ = 48 Rs.
a = float(input("Enter the amount in Rs:"))
b = a/48
print("The conversion of",a,"RS is $",b)