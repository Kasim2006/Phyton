#Convert Fahrenheit into celcius. C = 5/9 * (F – 32)
fh=int(input("Enter Degree fahrenheit:"))

print(fh,"degree fahrenheit is",(9/5)*(c-32),"degree celcius")
