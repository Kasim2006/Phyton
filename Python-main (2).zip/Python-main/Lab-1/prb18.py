#Calculate area & perimeter of a rectangle. A = L*B, P = 2 (L+B
length =float(input("Enter the Length:"))
width =float(input("Enter the width:"))

print("Area of rectangle is",length*width)
print("Parameter of rectangle is",2(length+width))
