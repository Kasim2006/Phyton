#TO CONVERT HOURS INTO MINUTES 
a = int(input("Enter hour:"))
b = a*60
print("The conversion of",a,"hour is",b,"minutes")