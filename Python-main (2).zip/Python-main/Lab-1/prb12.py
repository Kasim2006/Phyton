#Convert kgs into grams
a = int(input("Enter the number of kilograms:"))
b = a*1000
print("The conversion of",a,"kg is",b,"grams")