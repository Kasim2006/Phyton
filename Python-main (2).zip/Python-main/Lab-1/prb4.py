a=int(input("Enter first Number:"))
b=int(input("Enter Second Number:"))

print(a,"/",b,"=",a/b)
