#Convert dollars into pound where 1 $ = 48 Rs. And 1 pound = 70 Rs.2
a = float(input("Enter the amount of dollars:"))  
"""
Where, 1pound = 1.458$ 
""" 
b = a*1.458
print("The conversion of",a,"$ is ",b,"pounds")