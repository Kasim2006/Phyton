#Calculate area of a triangle. A = H*L/2
height=float(input("Enter the height of triangle:"))
base=float(input("Enter the base length of triangle:"))

print("Area of triangle is",base*height/2)
