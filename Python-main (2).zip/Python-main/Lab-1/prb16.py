#Calculate interest where I = PRN/100
principle =float(input("Enter Principle:"))
rate =float(input("Enter Rate:"))
time =float(input("Enter Time (In Year):"))

print("Interest of Given principle time and Rate is",(principle*time*rate)/100)
