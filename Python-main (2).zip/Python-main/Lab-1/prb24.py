#Swap two value
a=int(input("Enter Number A:"))
b=int(input("Enter Number B:"))

a,b=b,a


print("A=",a,"B=",b)
