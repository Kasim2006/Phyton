# TO CONVERT DOLLARS INTO RS (1$=RS48 )
a = float(input("Enter the number of dollars:"))
b =  a*48
print("The conversion of",a,"dollar is Rs",b)