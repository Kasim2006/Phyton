#Calculate area of a circle. A = 22/7 * R * R
radius =float(input("Enter the Radius of circle:"))

print("Area of circle is",(22/7)*radius*radius)
