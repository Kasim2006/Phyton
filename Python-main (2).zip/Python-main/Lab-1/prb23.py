# Calculate average of three subjects along with their total
sub1=int(input("Enter mark:"))
sub3=int(input("Enter mark:"))
sub2=int(input("Enter mark:"))

print("average of three is",(sub1+sub2+sub3)/3,"/n Total of three is",sub1+sub2+sub3)
