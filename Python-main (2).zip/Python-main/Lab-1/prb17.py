#Calculate area & perimeter of a square. A = L^2, P = 4L
side =float(input("Enter the side of square:"))

print("Area of square is",side**2)
print("Parameter of square is",4*side)
