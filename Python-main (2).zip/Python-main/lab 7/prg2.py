def empyy():
                d ={'A':'1'}
                if not d :
                                print("Empty dictionary")
                else:
                                print("Not Empty")

empyy()
