def dicno():
                d1= {'Hii':'1','Hello':'2','Byee':'3'}
                d2 = {'Ram':'4','Hari':'5'}
                d3={}
                d3.update(d1)
                d3.update(d2)
                print(d3)

dicno()
