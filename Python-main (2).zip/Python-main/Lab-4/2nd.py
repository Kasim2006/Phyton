def multiplication_Table(num):
    
    for i in range(1,11):
        print(num,"*",i,"=",num*i)



num=int(input("Enter Number:"))
multiplication_Table(num)