def compute(n):
    p = n*10+n
    q= p*10+n
    r= q*10+n
    print(n+p+q+r)

    
n = int(input("Enter any number:"))
compute(n)
