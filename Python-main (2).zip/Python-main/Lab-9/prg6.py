def ltcnt():
    lst=[]
    n = int(input("Enter the range:"))
    for i in range(1,n+1):
        p= (i**1,i**2,i**3)
        lst.append(p)
    print(lst)

ltcnt()
        
