import random

lst1=list(map(lambda x:x*x,[random.randint(-15,15) for _ in range(10)]))

print(lst1)