def convert():
    n =input("Enter any string:")
    n = n.replace(" ","")
    p = set(n)
    print(p)
convert()
