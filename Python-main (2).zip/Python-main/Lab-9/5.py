lis1=["samir","punit","viraj","krishnu "]

print(list(filter(lambda x: len(x)>=8, lis1)))