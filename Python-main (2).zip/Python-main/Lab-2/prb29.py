#Accept age of a person. If age is less than 18, print minor otherwise Major.
age = int(input("Enter the age of person:"))
if age>18:
    print("Major")
else:
    print("Minor")