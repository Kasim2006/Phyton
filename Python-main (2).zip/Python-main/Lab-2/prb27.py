#Check whether a given number is odd or even.
num = int(input("Enter any number:"))
if num%2==0:
    print(num,"is even number")
else:
    print(num,"is odd number")