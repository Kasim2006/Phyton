#Print largest and smallest values out of two.
a = int(input("Enter 1st number:"))
b = int(input("Enter 2nd number:"))
if a>b:
    print(a,"is the greatest")
else:
    print(b,"is the greatest")

    
if a<b:
    print(a,"is smallest")
else:
    print(b,"is the smallest")