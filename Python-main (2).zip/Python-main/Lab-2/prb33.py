#Print absolute value of a given number.
n = float(input("Enter any number:"))
m = abs(n)
print(f"The absolute value of {n} is {m}")