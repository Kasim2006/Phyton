#Accept a number from the user. And print number of digits in it.
nm= input("Enter any number:")
dig = len(nm)
print("The number of digits are",dig)