#Check whether a given number is divisible by 10 or not.
num= int(input("Enter any number:"))
if num%10==0:
    print(num,"is divisible by 10")
else:
    print(num,"is not divisible by 10")